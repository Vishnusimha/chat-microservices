package com.vishnu.discussion.exception;

public class ApiRequestException extends Exception {

    public ApiRequestException(String message) {
        super(message);
    }
}
