package com.vishnu.discussion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscussionApplicationTests {

    @Test
    void contextLoads() {
    }

}
