package com.vishnu.discussion.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CommentServiceTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void addCommentToPost() {
    }

    @Test
    void deleteCommentById() {
    }

    @Test
    void createComment() {
    }
}